import { Outlet, Navigate } from 'react-router-dom'
import {getCurrentUser } from '../../services/authService'
import React from 'react'

const PrivateRoutes = () => {
    const _user = getCurrentUser()
    return(
        (_user) ? 
        <Outlet/> : 
        <Navigate to="/login"/>
    )
}

export default PrivateRoutes
