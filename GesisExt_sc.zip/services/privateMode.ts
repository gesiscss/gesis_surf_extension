import { alarms, storage } from "webextension-polyfill";
import { updatePrivateMode } from "./syncService";

const PRIVATE_MODE = "user-private-mode";
export async function initPrivateMode() {
     await storage.local.set({"private":{"mode":false,"alarm":""}})
}

export async function getPrivateMode() {
    const _private  = await storage.local.get("private");
    return _private;
}

export async function setPrivateMode(val:boolean) {
    
    if(val){
        await storage.local.set({"private":{"mode":val,"alarm":new Date()}})
        await alarms.create('privatemode',{ periodInMinutes: 15 });
        updatePrivateMode(val,true);
        
    }else{
        await storage.local.set({"private":{"mode":val,"alarm":""}});
        alarms.clear('privatemode');
        updatePrivateMode(val,false);
    }   
}
