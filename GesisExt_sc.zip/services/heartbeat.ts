import { runtime, storage } from "webextension-polyfill";

let heartbeatInterval;

export async function runHeartbeat() {
  
  await storage.local.set({ 'last-heartbeat': new Date().getTime() });
}

export async function startHeartbeat() {
  // Run the heartbeat once at service worker startup.
  runHeartbeat().then(() => {
    // Then again every 20 seconds.
    heartbeatInterval = setInterval(runHeartbeat, 20 * 1000);
  });
}

export async function stopHeartbeat() {
  clearInterval(heartbeatInterval);
}

export async function getLastHeartbeat() {
  return (await storage.local.get('last-heartbeat'))['last-heartbeat'];
}



